<?php

namespace Willywes\AgoraSDK;

class AgoraSDK
{
    // Build wonderful things

    public static function Version()
    {
        return 'test';
    }
}
