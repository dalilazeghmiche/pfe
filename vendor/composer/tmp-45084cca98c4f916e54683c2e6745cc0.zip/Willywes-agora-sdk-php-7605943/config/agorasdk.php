<?php

return [
    'order' => [
        'by' => 'DESC',
        'as' => 'created_at',
    ],
];
