# Changelog

All notable changes to `Agora SDK PHP` will be documented in this file.

## Version 1.0

### Added
- Everything
